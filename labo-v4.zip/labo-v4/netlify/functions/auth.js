const JSONBIN_KEY = process.env.JSONBIN_KEY;
const JSONBIN_USERS_BIN = process.env.JSONBIN_USERS_BIN;
const BASE = 'https://api.jsonbin.io/v3';

async function getUsers() {
  if (!JSONBIN_USERS_BIN) return {};
  const r = await fetch(`${BASE}/b/${JSONBIN_USERS_BIN}/latest`, {
    headers: { 'X-Master-Key': JSONBIN_KEY }
  });
  const d = await r.json();
  return d.record || {};
}

async function saveUsers(users) {
  await fetch(`${BASE}/b/${JSONBIN_USERS_BIN}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json', 'X-Master-Key': JSONBIN_KEY },
    body: JSON.stringify(users)
  });
}

// Simple hash function (no bcrypt needed in edge functions)
function hashPassword(password) {
  let hash = 0;
  const str = password + 'labocarn_salt_2024';
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return Math.abs(hash).toString(36) + str.length.toString(36);
}

exports.handler = async function(event) {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers: { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Content-Type', 'Access-Control-Allow-Methods': 'POST, OPTIONS' }, body: '' };
  }
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method Not Allowed' };

  try {
    const { action, name, email, password } = JSON.parse(event.body);
    const users = await getUsers();

    if (action === 'register') {
      if (users[email]) {
        return { statusCode: 200, headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }, body: JSON.stringify({ success: false, error: 'Un compte existe déjà avec cet email.' }) };
      }
      users[email] = { name, password: hashPassword(password), createdAt: new Date().toISOString() };
      await saveUsers(users);
      return { statusCode: 200, headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }, body: JSON.stringify({ success: true, user: { name, email } }) };
    }

    if (action === 'login') {
      const user = users[email];
      if (!user) return { statusCode: 200, headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }, body: JSON.stringify({ success: false, error: 'Compte introuvable.' }) };
      if (user.password !== hashPassword(password)) return { statusCode: 200, headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }, body: JSON.stringify({ success: false, error: 'Mot de passe incorrect.' }) };
      return { statusCode: 200, headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }, body: JSON.stringify({ success: true, user: { name: user.name, email } }) };
    }

    if (action === 'saveBinId') {
      if (users[email]) {
        users[email].binId = event.body ? JSON.parse(event.body).binId : null;
        await saveUsers(users);
      }
      return { statusCode: 200, headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }, body: JSON.stringify({ success: true }) };
    }

    if (action === 'getBinId') {
      const user = users[email];
      return { statusCode: 200, headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }, body: JSON.stringify({ binId: user?.binId || null }) };
    }

    if (action === 'changePassword') {
      const { oldPassword, newPassword } = JSON.parse(event.body);
      const user = users[email];
      if (!user) return { statusCode: 200, headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }, body: JSON.stringify({ success: false, error: 'Compte introuvable.' }) };
      if (user.password !== hashPassword(oldPassword)) return { statusCode: 200, headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }, body: JSON.stringify({ success: false, error: 'Ancien mot de passe incorrect.' }) };
      users[email].password = hashPassword(newPassword);
      await saveUsers(users);
      return { statusCode: 200, headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }, body: JSON.stringify({ success: true }) };
    }

    if (action === 'deleteAccount') {
      delete users[email];
      await saveUsers(users);
      return { statusCode: 200, headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }, body: JSON.stringify({ success: true }) };
    }

    return { statusCode: 400, body: 'Invalid action' };
  } catch(e) {
    return { statusCode: 500, headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }, body: JSON.stringify({ error: e.message }) };
  }
};
