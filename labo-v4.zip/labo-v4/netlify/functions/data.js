const JSONBIN_KEY = process.env.JSONBIN_KEY;
const BASE = 'https://api.jsonbin.io/v3';

async function getUserBin(email) {
  // Chercher le bin de l'utilisateur
  const r = await fetch(`${BASE}/b?meta=false`, {
    headers: { 'X-Master-Key': JSONBIN_KEY }
  });
  // On utilise l'email encodé comme nom de bin
  const binName = 'user_' + email.replace(/[^a-z0-9]/gi, '_');
  return binName;
}

async function createBin(name, data) {
  const r = await fetch(`${BASE}/b`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-Master-Key': JSONBIN_KEY, 'X-Bin-Name': name, 'X-Bin-Private': 'true' },
    body: JSON.stringify(data)
  });
  const d = await r.json();
  return d.metadata?.id || null;
}

async function getBin(binId) {
  const r = await fetch(`${BASE}/b/${binId}/latest`, {
    headers: { 'X-Master-Key': JSONBIN_KEY }
  });
  const d = await r.json();
  return d.record || null;
}

async function updateBin(binId, data) {
  await fetch(`${BASE}/b/${binId}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json', 'X-Master-Key': JSONBIN_KEY },
    body: JSON.stringify(data)
  });
}

exports.handler = async function(event) {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers: { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Content-Type', 'Access-Control-Allow-Methods': 'POST, OPTIONS' }, body: '' };
  }
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method Not Allowed' };

  try {
    const { action, email, binId, data } = JSON.parse(event.body);

    if (action === 'create') {
      const name = 'user_' + email.replace(/[^a-z0-9]/gi, '_');
      const id = await createBin(name, { experiments: [], createdAt: new Date().toISOString() });
      return { statusCode: 200, headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }, body: JSON.stringify({ success: true, binId: id }) };
    }

    if (action === 'load') {
      const record = await getBin(binId);
      return { statusCode: 200, headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }, body: JSON.stringify({ success: true, data: record }) };
    }

    if (action === 'save') {
      await updateBin(binId, data);
      return { statusCode: 200, headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }, body: JSON.stringify({ success: true }) };
    }

    return { statusCode: 400, body: 'Invalid action' };
  } catch(e) {
    return { statusCode: 500, headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }, body: JSON.stringify({ error: e.message }) };
  }
};
